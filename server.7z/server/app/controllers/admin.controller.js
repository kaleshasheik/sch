const pool = require("../db/config");
const schoolModel = require("../model/school.model");
const isUserValid = require("../validations/user.validation");
const adminRepo = require("../repository/admin.repository");
const staffRepo = require("../repository/staff.repository");


exports.addAcademicYear = (req, res) => {
  let academicYear = new schoolModel(req.body);

  let academicYearDetails = {
    academicYearName: req.body.academicYearName,
    ledgerNumber: req.body.ledgerNumber,
    from: req.body.from,
    to: req.body.to
  };
  console.log('addAcademicYear', academicYearDetails)

  if (
    req.body.academicYearName &&
    req.body.ledgerNumber &&
    req.body.from &&
    req.body.to
  ) {
    adminRepo
      .addAcademicYear([academicYearDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "AcademicYearDetails created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({
            error: true,
            message: "AcademicYearDetails creation failed"
          });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Academic Year Data" });
  }
};

exports.editAcademicYear = (req, res) => {
console.log(' in academic year')
  let academicYearDetails = {
    academicYearName: req.body.academicYearName,
    ledgerNumber: req.body.ledgerNumber,
    from: req.body.from,
    to: req.body.to
  };

  console.log('addAcademicYear', academicYearDetails)

  if (
    req.body.academicYearName &&
    req.body.ledgerNumber &&
    req.body.from &&
    req.body.to
  ) {
    adminRepo
      .editAcademicYear(academicYearDetails, req.body.idAcademicYear)

      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "AcademicYearDetails updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "AcademicYearDetails update failed" });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Academic Year Data" });
  }
};

exports.fetchAllAcademicYears = (req, res) => {
  adminRepo
    .fetchAcademicYears()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "AcademicYearDetails Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to Fetch AcademicYearDetails" });
    });
};



exports.findAcademicYearById = (req, res) => {
  console.log(req.params);
  adminRepo
    .findAcademicYearById(req.params.idAcademicYear)
    .then(result => {
      return res
        .status(200)
        .send({
          error: false,
          data: result[0],
          message: "staff retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch staff " });
    });
};


exports.addGeneralentry = (req, res) => {

  if (req.body.type == 1) {

    addMedium(req, res)
  }
  else if (req.body.type == 2) {

    addReligion(req, res)
  }
  else if (req.body.type == 3) {
    addCaste(req, res)
  }
  else if (req.body.type == 4) {
    addCategory(req, res)

  }
  else if (req.body.type == 5) {
    addClass(req, res)
  }
  else if (req.body.type == 6) {
    addSection(req, res)

  }
  else if (req.body.type == 7) {

    addSubjectType(req, res)
  }
  else if (req.body.type == 8) {

    addSubject(req, res)
  }

}

addMedium = (req, res) => {
  console.log('add medium ', req.body)
  let mediumDetails = {
    mediumName: req.body.mediumName
  };

  if (req.body.mediumName) {
    adminRepo
      .addMedium([mediumDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Medium Details Added successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Medium Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Medium Data" });
  }
};

exports.editMedium = (req, res) => {
  let medium = new schoolModel(req.body);

  let mediumDetails = {
    mediumName: medium.mediumName,
    idMedium: req.mediumId
  };

  if (medium.mediumName) {
    adminRepo
      .editMedium([mediumDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Medium Details Updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to Update Medium Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Medium Data" });
  }
};

exports.fetchMedium = (req, res) => {
  adminRepo
    .editMedium()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Medium Details Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to Fetch Medium Details " });
    });
};

addReligion = (req, res) => {

  let religionDetails = {
    religionName: req.body.religionName
  };

  if (req.body.religionName) {
    adminRepo
      .addReligion([religionDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Religion Details created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Religion Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Religion Data" });
  }
};

exports.editReligion = (req, res) => {
  let religion = new schoolModel(req.body);

  let religionDetails = {
    religionName: religion.religionName,
    idReligion: req.idReligion
  };

  if (religion.religionName) {
    adminRepo
      .editReligion([religionDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Religion Details Updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to update Religion Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Religion Data" });
  }
};

exports.fetchReligion = (req, res) => {
  adminRepo
    .addReligion()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Religion Details Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to Fetch Religion Details " });
    });
};

addCaste = (req, res) => {

  let casteDetails = {
    casteName: req.body.casteName
  };

  if (req.body.casteName) {
    adminRepo
      .addCaste([casteDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Caste Details created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Caste Details " });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid Caste Data" });
  }
};

exports.editCaste = (req, res) => {
  let caste = new schoolModel(req.body);

  let casteDetails = {
    casteName: caste.casteName,
    idCaste: req.idCaste
  };

  if (caste.casteName) {
    adminRepo
      .editCaste([casteDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Caste Details Updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to update Caste Details " });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid Caste Data" });
  }
};

exports.fetchCaste = (req, res) => {
  adminRepo
    .fetchCaste()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Caste Details Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to Fetch Caste Details " });
    });
};

addCategory = (req, res) => {

  let categoryDetails = {
    categoryName: req.body.categoryName
  };

  if (req.body.categoryName) {
    adminRepo
      .addCategory([categoryDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Category Details created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Category Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid category Data" });
  }
};

exports.editCategory = (req, res) => {
  let category = new schoolModel(req.body);

  let categoryDetails = {
    categoryName: category.categoryName,
    idCategory: req.idCategory
  };

  if (category.categoryName) {
    adminRepo
      .editCategory([categoryDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Category Details Updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to Update Category Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid category Data" });
  }
};

exports.fetchCategory = (req, res) => {
  adminRepo
    .fetchCategory()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Category Details Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to Fetch Category Details " });
    });
};

addClass = (req, res) => {

  let classDetails = {
    className: req.body.className,
    description: req.body.description,
    isPrimary: req.body.isPrimary
  };

  if (req.body.className && req.body.description) {
    adminRepo
      .addClass([classDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Class Details created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Class Details " });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid class Data" });
  }
};

exports.editClass = (req, res) => {
  let classDetails = new schoolModel(req.body);

  classDetails = {
    className: classDetails.categoryName,
    classDescription: classDetails.classDescription,
    classPrimary: classDetails.classPrimary,
    idClass: req.idClass
  };

  if (classDetails.categoryName && classDetails.classDescription) {
    adminRepo
      .editClass([classDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Class Details Updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to Update Class Details " });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid class Data" });
  }
};

exports.fetchClasses = (req, res) => {
  adminRepo
    .fetchClasses()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Class Details Fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to add Fetch Details " });
    });
};

addSection = (req, res) => {

  console.log('addsection')
  let sectionDetails = {
    sectionName: req.body.sectionName
  };

  if (req.body.sectionName) {
    adminRepo
      .addSection([sectionDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Section Details created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Section Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Section Data" });
  }
};

exports.editSection = (req, res) => {
  let section = new schoolModel(req.body);

  let sectionDetails = {
    sectionName: section.sectionName,
    idSection: req.idSection
  };
  if (section.sectionName) {
    adminRepo
      .editSection([sectionDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Section Details updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to update Section Details " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Section Data" });
  }
};

exports.fetchSection = (req, res) => {
  adminRepo
    .fetchSection()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Section Details fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to fetch Section Details " });
    });
};

addSubjectType = (req, res) => {

  console.log('sub type', req.body)
  let subjectTypeDetails = {
    subjectTypeName: req.body.subjectTypeName
  };

  if (req.body.subjectTypeName) {
    adminRepo
      .addSubjectType([subjectTypeDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Subject Type created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Class Details " });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid class Data" });
  }
};

exports.editSubjectType = (req, res) => {
  let subjectType = new schoolModel(req.body);

  let subjectTypeDetails = {
    subjectTypeName: subjectType.subjectTypeName,
    idSubjectType: req.idSubjectType
  };

  if (subjectType.subjectTypeName) {
    adminRepo
      .editSubjectType([subjectTypeDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Subject Type updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to update Subject Types " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid SubjectType Data" });
  }
};

exports.fetchSubjectTypes = (req, res) => {
  adminRepo
    .fetchSubjectTypes()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Subject Type fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to fetch Subject Types " });
    });
};

addSubject = (req, res) => {
  let subject = new schoolModel(req.body);

  let subjectDetails = {
    subjectCode: req.body.subjectCode,
    subjectName: req.body.subjectName,
    idSubjectType: req.body.idSubjectType,
    idMedium: req.body.idMedium
  };

  if (req.body.subjectCode && req.body.subjectName) {
    adminRepo
      .addSubject([subjectDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Subject created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to add Subject  " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Subject Data" });
  }
};

exports.editSubject = (req, res) => {
  let subject = new schoolModel(req.body);

  let subjectDetails = {
    subjectCode: subject.subjectCode,
    subjectName: subject.subjectTypeName,
    idSubjectType: subject.subjectType,
    idMedium: subject.subjectMediumType,
    idSubject: req.idSubject
  };

  if (subject.subjectCode && subject.subjectTypeName) {
    adminRepo
      .editSubject([subjectDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "Subject updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Failed to update Subject  " });
      });
  } else {
    return res
      .status(400)
      .send({ error: true, message: "Invalid Subject Data" });
  }
};

exports.fetchSubjects = (req, res) => {
  adminRepo
    .fetchSubjects()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Subjects fetched successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Failed to fetch Subjects " });
    });
};

exports.fetchAllGeneralEntries = (req, res) => {
  console.log(' fetchAllGeneralEntries')
  const promises = [
    adminRepo.fetchMedium(),
    adminRepo.fetchReligion(),
    adminRepo.fetchCaste(),
    adminRepo.fetchCategory(),
    adminRepo.fetchClasses(),
    adminRepo.fetchSection(),
    adminRepo.fetchSubjectTypes(),
    adminRepo.fetchSubjects()

  ]

  Promise.all(promises).then((data) => {

    let result = {
      'mediumList': data[0], 'religionList': data[1], 'casteList': data[2],
      'categoryList': data[3], 'classList': data[4], 'sectionList': data[5],
      'subjectTypeList': data[6], 'subjectList': data[7]
    }
    return res
      .status(200)
      .send({
        error: false,
        data: result,
        message: "General Entries fetched successfully"
      });
  });


}




exports.fetchAllClassSectionStaff = (req, res) => {
  console.log(' fetchAllClassSectionStaff')
  const promises = [
    adminRepo.fetchClasses(),
    adminRepo.fetchSection(),
    staffRepo.getAllStaffUsers()
  ]

  Promise.all(promises).then((data) => {
    let classResult = data[0]
    classResult.unshift({
      idClass: 0,
      className: "Choose Class"
    }); 
    let sectionResult = data[1]
    sectionResult.unshift({
      idSection: 0,
      sectionName: "Choose Section"
    }); 
    let staffResult = data[2]
    staffResult.unshift({
      idStaff: 0,
      firstName: "Choose Class Teacher",
      lastName:""
    });      
    let result = {
      
       'classList': classResult, 'sectionList': sectionResult,
      'staffList': staffResult, 
    }
    return res
      .status(200)
      .send({
        error: false,
        data: result,
        message: "General Entries fetched successfully"
      });
  });


}
