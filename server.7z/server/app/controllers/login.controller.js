const bcrypt = require("bcryptjs");
const pool = require("../db/config");
const schoolModel = require("../model/school.model");
const loginRepo = require("../repository/login.repository");

// create user
exports.login = (req, res) => {
  let userData = new schoolModel(req.body);
  // hash password
  const salt = bcrypt.genSalt(10);
  // const hashPassword = bcrypt.hash(req.password, salt)

  if (userData.emailId && userData.password) {
    loginRepo
      .login(userData.emailId, userData.password)
      .then(result => {
        if (result.length == 0) {
          return res
            .status(400)
            .send({ error: true, status: 400, message: "login failed" });
        } else {
          return res
            .status(200)
            .send({
              error: false,
              data: result[0],
              status: 200,
              message: "User logged-in successfully"
            });
        }
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, status: 400, message: "login failed" });
      });
  } else {
    return res.status(404).send({ error: true, message: "Invalid login Data" });
  }
};
