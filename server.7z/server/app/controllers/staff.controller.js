const pool = require("../db/config");
const schoolModel = require("../model/school.model");
const staff = require("../validations/staff.validation");
const staffRepo = require("../repository/staff.repository");
const user = require("../validations/user.validation");
const userRepo = require("../repository/user.repository");

exports.addStaff = (req, res) => {
  let staffData = new schoolModel(req.body);
  let staffDetails = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    adhaarNumber: req.body.adhaarNumber,
    gender: req.body.gender,
    permanent_address: req.body.permanent_address,
    correspondance_address: req.body.correspondance_address,
    nationality: req.body.nationality,
    dob: req.body.dob
  };
  // const salt = bcrypt.genSalt(10);
  // const hashPassword = bcrypt.hash('123456', salt)

  let userDetails = {
    userName: req.body.firstName + " " + req.body.lastName,
    emailId: staffData.emailId,
    password: '12345',
    status: 1,
    mobileNumber: staffData.mobileNumber,
    profileImage: staffData.profileImage,
    idUserType: 1
  };

 
  if (staff.isStaffValid(staffDetails)) {
    userRepo
      .createUser([userDetails])
      .then(result => {
        let staffDetails = {
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          adhaarNumber: req.body.adhaarNumber,
          gender: req.body.gender,
          permanent_address: req.body.permanent_address,
          correspondance_address: req.body.correspondance_address,
          nationality: req.body.nationality,
          dob: req.body.dob,
          iduser: result.insertId
        }

        staffRepo
          .addStaff([staffDetails])
          .then(result => {
            return res
              .status(201)
              .send({
                error: false,
                data: result,
                fields: fields,
                message: "Staff created successfully"
              });
          })
          .catch(err => {
            return res
              .status(400)
              .send({ error: true, message: "Staff creation failed" });
          });
          
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Staff creation failed" });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid Staff Data" });
  }
};

exports.editStaff = (req, res) => {
  let staffData = new schoolModel(req.body);

  console.log('staff modufy', req.body)
  let staffDetails = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    adhaarNumber: req.body.adhaarNumber,
    gender: req.body.gender,
    permanent_address: req.body.permanent_address,
    correspondance_address: req.body.correspondance_address,
    nationality: req.body.nationality,
    dob: req.body.dob
  };
  // const salt = bcrypt.genSalt(10);
  // const hashPassword = bcrypt.hash('123456', salt)

  let userDetails = {
    userName: req.body.firstName + " " + req.body.lastName,
    emailId: staffData.emailId,
    password: '12345',
    status: 1,
    mobileNumber: staffData.mobileNumber,
    profileImage: staffData.profileImage,
    idUserType: 1
  };

 console.log('modufy staff', staffDetails, userDetails)
  if (staff.isStaffValid(staffDetails)) {
    userRepo
    .updateUser(userDetails, req.body.idUser)
      .then(result => {
        staffRepo
        .updateStaff(staffDetails, req.body.idStaff)
          .then(result => {
            return res
              .status(201)
              .send({
                error: false,
                data: result,
                fields: fields,
                message: "Staff created successfully"
              });
          })
          .catch(err => {
            return res
              .status(400)
              .send({ error: true, message: "Staff creation failed" });
          });
          
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "Staff creation failed" });
      });
  }else {
    return res.status(400).send({ error: true, message: "Invalid Staff Data" });
  }
};

// fetch all users
exports.findStaff = (req, res) => {
  console.log(req.params);
  staffRepo
    .findStaff(req.params.idUser)
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result[0],
          message: "Users retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch users failed" });
    });
};

// fetch all users
exports.getAllStaffUsers = (req, res) => {
  staffRepo
    .getAllStaffUsers()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Users retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch users failed" });
    });
};


exports.findStaffById = (req, res) => {
  console.log(req.params);
  staffRepo
    .findStaffById(req.params.idStaff)
    .then(result => {
      return res
        .status(200)
        .send({
          error: false,
          data: result[0],
          message: "staff retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch staff " });
    });
};