const bcrypt = require("bcryptjs");
const pool = require("../db/config");
const schoolModel = require("../model/school.model");
const user = require("../validations/user.validation");
const userRepo = require("../repository/user.repository");

// create user
exports.addUser = (req, res) => {
  let userData = new schoolModel(req.body);
  // hash password
  const salt = bcrypt.genSalt(10);
  // const hashPassword = bcrypt.hash('123456', salt)

  let userDetails = {
    userName: userData.userName,
    emailId: userData.emailId,
    password: userData.password,
    status: userData.status,
    mobileNumber: userData.mobileNumber,
    profileImage: userData.profileImage,
    idUserType: userData.idUserType
  };
  if (user.isUserValid(userData)) {
    console.log("new user is valid");
    userRepo
      .createUser([userDetails])
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "User created successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "User creation failed" });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid User Data" });
  }
};

//edit user
exports.modifyUser = (req, res) => {
  console.log("modify user is valid");

  var userData = new schoolModel(req.body);

  var userDetails = {
    userName: userData.userName,
    emailId: userData.emailId,
    password: userData.password,
    status: userData.status,
    mobileNumber: userData.mobileNumber,
    profileImage: userData.profileImage,
    idUserType: userData.idUserType
  };
  console.log("modify", userDetails);
  if (user.isUserValid(userData)) {
    userRepo
      .updateUser(userDetails, req.body.idUser)
      .then(result => {
        return res
          .status(201)
          .send({
            error: false,
            data: result,
            message: "User updated successfully"
          });
      })
      .catch(err => {
        return res
          .status(400)
          .send({ error: true, message: "User update failed" });
      });
  } else {
    return res.status(400).send({ error: true, message: "Invalid User Data" });
  }
};

exports.findUser = (req, res) => {
  console.log(req.params);
  userRepo
    .findUser(req.params.idUser)
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result[0],
          message: "Users retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch users failed" });
    });
};

// fetch all users
exports.getAllUsers = (req, res) => {
  userRepo
    .getAllUsers()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "Users retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch users failed" });
    });
};

exports.fetchUserTypes = (req, res) => {
  console.log("fetchyuser types");
  userRepo
    .getAllUsersTypes()
    .then(result => {
      return res
        .status(201)
        .send({
          error: false,
          data: result,
          message: "User Types retrieved successfully"
        });
    })
    .catch(err => {
      return res
        .status(400)
        .send({ error: true, message: "Unable to fetch user typesfailed" });
    });
};
