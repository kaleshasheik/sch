const pool = require("../db/config");

exports.login = (email, password) => {
  console.log("login", email, password);
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      var query = pool.query(
        'SELECT * from tblUserDetails WHERE emailId = "' +
          email +
          '" And password = "' +
          password +
          '"',
        (error, results, fields) => {
          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(results);
          }
        },
        2000
      );
      console.log("login user", query.sql);
    });
  });
};
