const pool = require("../db/config");

exports.addStaff = (staffDetails) => {
 
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      var query = pool.query(
        
          "INSERT INTO tblstaffdetails SET ? ",
          staffDetails,
          (error, results, fields) => {

          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(results);
          }
        },
        2000
      );
      console.log("create staff", query.sql);
    });
  });
};


exports.updateStaff = (staffDetails, idStaff) => {
  console.log("id updateStaff", idStaff, staffDetails);
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      var query = pool.query(
        "UPDATE tblstaffdetails SET  ? WHERE idStaff = '" + idStaff + "'",
        [staffDetails],
        (error, results, fields) => {
          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(results);
          }
        },
        2000
      );
      console.log("update staff", query.sql);
    });
  });
};

exports.findStaff = idStaff => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      pool.query(
        "SELECT * FROM tblstaffdetails WHERE idStaff = ?",
        idStaff,
        (error, result) => {
          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(result);
          }
        },
        2000
      );
    });
  });
};

exports.getAllStaffUsers = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      pool.query(
        "SELECT * FROM tblstaffdetails",
        (error, result) => {
          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(result);
          }
        },
        2000
      );
    });
  });
};


exports.findStaffById = idStaff => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      pool.query(
        "SELECT * FROM tblstaffdetails WHERE idStaff = ?",
        idStaff,
        (error, result) => {
          if (error) {
            reject("Opps!. Something went wrong");
          } else {
            resolve(result);
          }
        },
        2000
      );
    });
  });
};