const userRoutes = require('./user.routes');
const staffRoutes = require('./staff.routes')
const adminRotes = require('./admin.routes')
console.log('admin routes', userRoutes)

module.exports = (app) => {
    const user = require('../controllers/user.controller.js');
    const login = require('../controllers/login.controller.js');

    userRoutes(app);
    staffRoutes(app);
    adminRotes(app);
   /* app.post('/api/addUser', user.addUser)
    app.post('/api/modifyUser', user.modifyUser)
    app.get('/api/fetchUserTypes', user.fetchUserTypes)
    app.get('/api/fetchAllUsers', user.getAllUsers)
    app.get('/api/fetchUserById/:idUser', user.findUser)
    app.post('/api/login', login.login)*/
}