module.exports = (app) => {
    const staff = require('../controllers/staff.controller.js');

    app.post('/api/addStaff', staff.addStaff)
    app.post('/api/modifyStaff', staff.editStaff)
    app.get('/api/fetchAllStaffUser', staff.getAllStaffUsers)
    app.get('/api/fetchStaffById/:idStaff', staff.findStaffById)

}