exports.isStaffValid = staffData => {

  console.log('staffdata ', staffData)
  if (
    staffData.firstName &&
    staffData.lastName &&
    staffData.adhaarNumber &&
    staffData.gender &&
    staffData.permanent_address &&
    staffData.correspondance_address &&
    staffData.nationality &&
    staffData.dob
  ) {
    return true;
  } else {
    return false;
  }
};
