exports.isUserValid = userData => {
  if (
    userData.userName &&
    userData.emailId &&
    userData.mobileNumber &&
    userData.status &&
    userData.idUserType
  ) {
    return true;
  } else {
    return false;
  }
};
